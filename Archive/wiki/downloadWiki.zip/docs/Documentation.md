+**Viva Music Player User Guide**+

* Start the application by double click on it.

* Then select the "File" tab, click the "Open", a file dialogue should appear and you can open yours favourite music by double click on it. (Note: You may able to choose multiple files, Viva Music Player will handle it.)

* You can pause, play, next, previous the track list, and repositioning the playing track by scroll the slider.

* That's it, feel free to enjoy!