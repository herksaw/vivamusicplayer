About Viva Music Player 0.6.7

Viva Music Player is a free and open source music player. It's using C# and NAudio audio library to play audio files.

Current version: 0.6.7

Copyright (C) 2012 by Herks Aw.

----------------------------------------------
Release history:-

Viva Music Player 0.6.7 released. 2 Oct 2012

Add wav format support.
Minor correction on title name.
Minor improvement on canvas screen and button size, etc.
Minor filedialog title correction.
Add a slider.
Major code improvement and cleaner.
Bugs and exceptions fix in timeline.
Show currently playing file name and length.

Viva Music Player 0.3.2 released. 29 Sep 2012

Automatic play the next file in a track list.
Minor code improvement on checking title name.

Viva Music Player 0.2.1 released. 26 Sep 2012

Add ability to perform next and previous actions in a track list.

Viva Music Player 0.1.1 released. 23 Sep 2012
(Initial release.)

Add mp3 format support.
Gain the ability to play and pause the track.

----------------------------------------------

    This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along with this program. If not, see <http://www.gnu.org/licenses/>.



